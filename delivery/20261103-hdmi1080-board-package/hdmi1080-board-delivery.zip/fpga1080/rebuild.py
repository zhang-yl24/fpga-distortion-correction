"""One-command source rebuild through a labelled diagnostic bitstream.

Uses the recipient's installed PDS and stops immediately on any failed stage.
No JTAG, UART, Flash, or hardware programming is performed.
"""
from pathlib import Path
from datetime import datetime
import argparse
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
FLOW=ROOT/'delivery/20261103-hdmi1080-throughput/tools/build_board_candidate.py'

def run(command):
    print('Running: '+subprocess.list2cmdline([str(x) for x in command]),flush=True)
    subprocess.run([str(x) for x in command],cwd=ROOT,check=True)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pds-shell',type=Path,required=True)
    p.add_argument('--output-root',type=Path,default=Path('C:/fpga-build'))
    p.add_argument('--variant',choices=('baseline','writer','cache','both'),default='cache')
    p.add_argument('--mode',choices=('corrected','raw','demo'),default='corrected')
    p.add_argument('--run-name')
    p.add_argument('--seed',type=int,default=1)
    p.add_argument('--timeout-seconds',type=int,default=10800)
    a=p.parse_args()
    if not a.pds_shell.is_file():p.error('PDS executable was not found')
    run_name=a.run_name or (a.variant+'-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
    output=a.output_root.resolve()
    work=output/run_name
    common=[sys.executable,'-B',FLOW]
    try:
        run(common+['prepare','--dependency-native',ROOT/'native-dependencies',
                    '--output-root',output,'--run-name',run_name,
                    '--variant',a.variant,'--mode',a.mode])
        for stage in ('map','route','sta','bitstream'):
            command=common+['run','--work',work,'--stage',stage,'--pds-shell',a.pds_shell.resolve(),
                            '--seed',str(a.seed),'--timeout-seconds',str(a.timeout_seconds)]
            if stage=='bitstream':command.append('--diagnostic-bit')
            run(command)
    except subprocess.CalledProcessError as exc:
        print('Build stopped. Keep the failed stage logs under '+str(work),file=sys.stderr)
        return exc.returncode if exc.returncode else 1
    receipt=json.loads((work/'bitstream-result.json').read_text(encoding='utf-8'))
    if not receipt.get('stage_completed') or receipt.get('label')!='DIAGNOSTIC_NOT_TIMING_SIGNOFF':
        raise RuntimeError('A completed labelled diagnostic bitstream receipt is required')
    print(json.dumps({'completed':True,'work':str(work),'label':receipt['label'],
                     'bitstream':receipt['artifacts']['exported_bitstream'],
                     'hardware_verified':False,'hardware_programmed':False},indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
