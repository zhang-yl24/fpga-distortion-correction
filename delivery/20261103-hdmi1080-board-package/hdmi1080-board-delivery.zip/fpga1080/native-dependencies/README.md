# Local exact native dependencies

80 of 80 external source dependencies match the frozen delivery manifest byte length and SHA256. This directory is local build input and remains outside the Git repository. Original vendor files and licenses are unchanged.

Use this directory as the `--dependency-native` argument to the throughput candidate preparation tool. It contains dependency sources only; preparation obtains the 50 project sources from the frozen delivery package.

Reproduce or verify the recovery using Python 3.10+:

```powershell
python -B recover_native_dependencies.py --repo C:/Users/Lenovo/Documents/Codex/2026-11-02/2026-fpga/work/repo --verify-only
```

Remove `--verify-only` to populate a new `--out` directory. Every derived output is checked against the original manifest before writing. The three reconstructed historical files use source-bound module/reset/trigger changes, recorded in `recovery-report.json`; the RX module rename was identified by the root agent. All other dependencies are exact repository source matches.
