# HDMI 1080p 校正工程：解压后入口

本包包含冻结演示源码 50 项、候选源码/测试/文档，以及按原清单匹配的 80 项原生依赖。
工程目标为盘古 100Pro+ 的 PG2L100H、FBG676、-6，使用 1080p29.97/30 的 DDR 校正路径。
当前参数仍为 Penn 开发配置、零旋转和 Gamma OFF；真实镜头标定及优化后实板指标按实际验收补录。
本包已附 baseline、both、cache 三份固定纯校正诊断位流，均已完成原生导出；优化后实板验收待完成。
当前结果支持诊断测试和性能对照，1080p60 稳定纯校正仍待实现与实测。
一键重建入口用于复现当前封存参数下的 baseline/cache/both 性能候选。真实镜头 K/D 的受控
参数导入、身份绑定及匹配回归另行完成；本入口尚未提供直接更换标定文件的选项。

## 1. 解压与核验

建议解压到短路径 `D:/fpga/`，得到 `D:/fpga/fpga1080/`。保留目录结构。
本地编译工具使用接收方已安装、授权有效的 PDS 2025.2；包内未包含工具程序或授权文件。
在 `fpga1080` 目录执行（Python 3.10+）：

```powershell
python -B verify_package.py
python -B delivery/20261103-hdmi1080-demo-source/tools/verify_package.py
python -B delivery/20261103-hdmi1080-throughput/tools/verify_delivery.py
python -B delivery/20261103-hdmi1080-throughput/tools/recover_native_dependencies.py --verify-only --out native-dependencies
```

原始源码包说明中的“80 项依赖未随源码包发布”描述原 Git 源码包；本地交付 ZIP 已在
`native-dependencies/` 单独补齐。原厂文件维持原字节与原使用条件。恢复说明及文件来源随包保留。

## 2. 在接收方电脑重新准备完整工程

从包根目录执行一条命令，替换 PDS 的安装路径：

```powershell
python -B rebuild.py --pds-shell E:/PDS_2025.2-ads-win64/pango/PDS_2025.2-ads/bin/pds_shell.exe --output-root D:/fpga-build2 --variant both
```

入口顺序执行 prepare、Map、PNR、双角 STA、诊断位流导出；任一步失败立即停止并保留日志。
每次自动生成新 run 名，也可用 `--run-name both-01` 指定。`--seed` 和 `--timeout-seconds`
可选。完整分阶段命令与失败检查见候选目录的 `docs/BOARD_BUILD_NOTES.md`。

使用新的 run 名重试或改变配置。`baseline/writer/cache/both` 与 `corrected/raw/demo`
分别选择优化方案与显示模式；性能测量采用 `corrected`。本次推荐先用 baseline 确认同一
输入源和测量方法，再用 both 测量联合优化；cache 用作缓存单项优化对照。命令示例显式
选择 `--variant both`；入口省略该参数时仍默认 cache。
一键入口产物带 `DIAGNOSTIC_NOT_TIMING_SIGNOFF` 标签，并保留时序失败信息。
同学可在 PDS 中打开接收方本次生成的原生工程；脚本保留阶段日志与源码/数据库绑定。

默认位流导出要求时序、IO、CDC/复位检查通过。需要受控诊断测试时，先查看新 STA
与 144 引脚审计，再按 `docs/BOARD_BUILD_NOTES.md` 中的显式诊断导出流程操作。
标记为 `DIAGNOSTIC_NOT_TIMING_SIGNOFF` 的位流仍处于诊断状态，板测和正式时序验收待完成。
打包、准备和构建脚本均不操作 JTAG、串口或 Flash。

## 3. 当前随包板级构建状态

- `baseline`：baseline / corrected，param_id `b0481b1d`；map=完成, route=完成, sta=完成, bitstream=完成。原始证据见 `board-builds/baseline/`。
- `both`：both / corrected，param_id `f36cb459`；map=完成, route=完成, sta=完成, bitstream=完成。原始证据见 `board-builds/both/`。
- `cache`：cache / corrected，param_id `1a247c5b`；map=完成, route=完成, sta=完成, bitstream=完成。原始证据见 `board-builds/cache/`。

| 版本 | Slow Setup 违规端点 | 最差裕量（ns） |
| --- | ---: | ---: |
| baseline | 62 | -0.659 |
| both | 16 | -0.619 |
| cache | 155 | -0.762 |

表中数值直接读取随包构建的独立 STA 回执。三份最终构建均保留 DDR recovery/removal
违规，诊断标签随位流保留；当前时序结果尚未达到正式签核要求。推荐 baseline → both
的板测顺序，并记录 cache 单项对照，分别采集固定纯校正的唯一输出 FPS 与同源画质。

详见 `PACKAGE_STATUS.json`，它逐项保留原阶段状态与时序摘要。附带的构建快照保留原始
绝对路径和历史输入身份，迁移后用于追溯；重新构建请执行上面的 prepare，生成接收方
路径下的新绑定。已完成 Map、PNR、STA 或 bitgen 均不自动代表优化后的实板验收通过。
已完成导出的位流另放在 `bitstreams/baseline/`、`bitstreams/cache/`、`bitstreams/both/`
等目录，各目录 `STATUS.json` 标注是否有文件及对应配置身份。没有生成的位流维持待完成状态。

## 4. 仿真、分析与待补材料

CPU 核验使用标准库。完整引擎仿真还需要 NumPy 与 Vivado XSim；本次参考仿真使用
Vivado 2017.4。可用 `python -m pip install -r requirements-simulation.txt` 安装 NumPy。
若使用随包标定辅助工具，另外按 `distortion/requirements.txt` 准备 OpenCV 等依赖。
RTL 回归入口见候选 README 的“重现验证”；独立 scalar golden 位于
`distortion/tools/generate-brown-vectors.py`，包内已包含。

```powershell
python -B -m unittest discover -s delivery/20261103-hdmi1080-throughput/tests -p test_*.py -v
```

上板操作、原始 UART 采集与唯一输出 FPS 分析见
`delivery/20261103-hdmi1080-throughput/BOARD_HANDOFF.md`。
逐项基础/高阶任务状态见 `ACCEPTANCE_AUDIT.md`。当前交付尚需真实镜头同源画质、固定纯
校正 FPS、端到端延迟、连续运行与最终时序验收。已有 1080p60 摄像头直通成绩分别归档，
本包的处理性能结果属于 DDR 校正路径。
