"""Verify extracted board-package bytes using only Python's standard library."""
from pathlib import Path, PurePosixPath
import hashlib
import json
ROOT=Path(__file__).resolve().parent
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
manifest=json.loads((ROOT/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
for row in manifest['files']:
    rel=PurePosixPath(row['path'])
    if rel.is_absolute() or '..' in rel.parts:raise ValueError('Unsafe manifest path')
    p=(ROOT/row['path']).resolve()
    if not p.is_relative_to(ROOT) or not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:
        raise ValueError('Missing or changed package file: '+row['path'])
print(json.dumps({'verified_files':len(manifest['files']),'source_bytes_verified':True,
                  'hardware_verified':False,'note':'Read PACKAGE_STATUS.json for archived stage status.'},indent=2))
