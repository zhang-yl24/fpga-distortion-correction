# 三结果帧缓冲实验版 A

本包不是已验证的60新帧版本。已完成实际PDS综合、布线、双角时序和位流生成，最终网表ROM初始化逐词一致；尚未烧录或实板验证。

- 输入：1080p60摄像头；KEY1原始/校正切换；不新增旋转。
- 核心125 MHz，显示148.5 MHz；采用三结果槽缓冲候选，不含single-beat B或owner C候选。
- 位流：bitstream/aa-result3-camera1080p60-key1-9abf8895.sbit。烧录前必须核对BUILD_IDENTITY.json中的完整SHA256。
- 使用既有同型号开发板和原相机/镜头；先保留已成功旧位流。仅作实验SRAM测试，不要求改永久启动镜像。
- 检查出图、校正效果、KEY1两状态；记录实测相机输入模式/频率，不把显示扫描60 Hz当新画面60 fps。
- 重点比较此前三新一重复是否消失；若相机59.94而显示60.01，少量时钟差重复应与25%重复区分。
- 遥测：本版含slot2，旧062工具不得直接套用。精确新位流profile尚待补齐；保留完整原始UART，不能拿旧param_id当位流身份。
- 完整300秒校正、KEY1稳定窗口、CRC/丢包/fault、输入频率与新呈现速率共同作为后续验收。当前这些均未执行。

源码入口 source/research/aa-elastic-result-buffer，构建入口 source/research/aa-elastic-build-handoff。重建需要用户合法持有的原164文件私有seed及PDS/DDR IP；本包不包含厂商源码、许可证、网表或私有路径。源码与固定GitHub提交逐文件对应，完整复现须按构建说明准备依赖。

reports/final-timing-sanitized.rtr仅替换了本地构建根路径；原始和脱敏副本SHA均记录在BUILD_IDENTITY.json。最终内部时序满足不等于外部IO/CDC/实板验收全部通过。
