"""CPU-only validation; no serial, FPGA, network or package installation."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
host = root / 'host'
logs = root / 'logs'
logs.mkdir(exist_ok=True)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
result = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-v'],
                        cwd=host, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(logs / 'validation_tests.log').write_text(result.stdout)
print(result.stdout, end='')
syntax_errors = []
for path in sorted(host.glob('*.py')):
    try:
        compile(path.read_text(), str(path), 'exec')
    except (SyntaxError, ValueError) as error:
        syntax_errors.append(f'{path.name}: {error}')
expected = json.loads((root / 'evidence/legacy_host_sha256_before.json').read_text())
unchanged_test_files = {
    name: hashlib.sha256((host / name).read_bytes()).hexdigest() == expected[name]
    for name in ('test_aa_tools.py', 'test_aa_continuous.py')}
validation = {
    'TimestampUTC': datetime.now(timezone.utc).isoformat(),
    'Python': sys.version,
    'Command': [sys.executable, '-m', 'unittest', 'discover', '-v'],
    'TestExitCode': result.returncode,
    'SyntaxErrors': syntax_errors,
    'OriginalTestFilesUnchanged': unchanged_test_files,
    'PhysicalUARTOpened': False,
    'FPGAResetOrKEY1Used': False,
    'RTLOrBitstreamModified': False,
    'HardwarePassClaim': False,
    'Scope': 'Python synthetic packets, fake transport/clock, offline CLI and in-memory syntax checks only',
}
(logs / 'VALIDATION.json').write_text(json.dumps(validation, indent=2) + '\n')
if result.returncode or syntax_errors or not all(unchanged_test_files.values()):
    raise SystemExit(1)
