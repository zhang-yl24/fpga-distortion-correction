"""Hash one operator-selected local sbit. Does not program or query an FPGA."""
import argparse
import json
from aa_measure import file_sha256
from aa_profiles import SLOT2_PROFILE, get_profile


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('sbit')
    a = p.parse_args()
    try:
        observed = file_sha256(a.sbit)
    except OSError as error:
        p.exit(2, f'Cannot read local sbit: {error}\n')
    expected = get_profile(SLOT2_PROFILE).bitstream_sha256
    if observed != expected:
        p.exit(2, f'REJECTED: local sbit SHA256 {observed} does not match {expected}\n')
    print(json.dumps({'LocalFileSHA256Matches': True, 'SHA256': observed,
                      'Profile': SLOT2_PROFILE, 'LoadedFPGAIdentityAuthenticated': False,
                      'FPGAProgrammedOrUARTOpened': False}, indent=2))


if __name__ == '__main__':
    main()
