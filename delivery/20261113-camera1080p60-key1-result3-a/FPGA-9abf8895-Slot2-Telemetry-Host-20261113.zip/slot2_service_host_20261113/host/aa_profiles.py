"""Closed, immutable identity profiles. Never infer a profile from wire tags.

The shared 0xadfb7264 tag is a static RTL lookup tag, NOT a bitstream hash.
The SHA supplied by the operator is recorded, not read back/authenticated.
"""
from dataclasses import dataclass
from types import MappingProxyType


@dataclass(frozen=True)
class Profile:
    name: str
    bitstream_sha256: str
    parameter_id: int
    core_hz: int
    service_diagnostics: bool = False
    result_slots: int = 2


LEGACY_PROFILE = 'aa-legacy-1665586d'
RUN8_PROFILE = 'run8-on-head1-ca135-a41-062c79b7'
SLOT2_PROFILE = 'run8-elastic-result3-slot2-9abf8895'
PROFILES = MappingProxyType({
    LEGACY_PROFILE: Profile(LEGACY_PROFILE,
        '1665586da54bdbf5ed8cefa7d0bbe35f3cbb0219e03ae060fa68f6dfdb717f8a',
        0xadfb7264, 125000000),
    RUN8_PROFILE: Profile(RUN8_PROFILE,
        '062c79b745c3bb582f90a3a36aee28ab75e2481d893403cb028fae4bd9c002f3',
        0xadfb7264, 125000000, True),
    SLOT2_PROFILE: Profile(SLOT2_PROFILE,
        '9abf8895212af90b5c55c7fcdc442c6a75cc425187be69a8511bbd16aff6663a',
        0xadfb7264, 125000000, True, 3),
})


def get_profile(name=LEGACY_PROFILE):
    # Accept registered names only, not caller-constructed policy objects.
    if not isinstance(name, str) or name not in PROFILES:
        raise ValueError('Unknown profile; select one of: ' + ', '.join(PROFILES))
    return PROFILES[name]


def validate_manifest_profile(manifest, profile):
    selected = get_profile(profile)
    recorded = manifest.get('Profile')
    if recorded != selected.name and not (recorded is None and selected.name == LEGACY_PROFILE):
        raise ValueError('Capture Profile differs from explicitly selected profile '
                         '(Run8 requires an explicit Profile in the manifest)')
    if manifest.get('LoadedBitstreamSHA256OperatorSupplied') != selected.bitstream_sha256:
        raise ValueError('Capture bitstream SHA256 does not match the selected profile')
    return selected
