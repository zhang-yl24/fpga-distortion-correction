"""Sample-limited Run8 service diagnostics from unchanged PGSTAT02 LIGHT.

No UART/device operations. Raw cycle counts are NOT derived from frame rate.
No population service distribution or busy duty cycle can be recovered here.
"""
from fractions import Fraction
from statistics import mean, median

REFERENCE_SCAN_FPS = Fraction(6001, 100)


class ServiceSamples:
    def __init__(self, core_hz):
        self.core_hz = core_hz
        self.budget = Fraction(core_hz, 1) / REFERENCE_SCAN_FPS
        self.samples = []
        self.previous = None
        self.missing_completions = 0
        self.observed_interval_completions = 0
        self.repeated_observations = 0

    def observe(self, snapshot, processed_delta=None):
        """Called only on identity/mode/clock/epoch-checked snapshots.

        completed_frame_id identifies the most recent completed source frame.
        Frame-ID gaps are NOT a count of completions; source IDs may skip.
        A monotonically advancing ID makes adjacent duplicate checking enough.
        """
        frame_id = snapshot['completed_frame_id']
        cycles = snapshot['last_process_cycles_raw']
        if cycles == 0:
            raise ValueError('Valid completion has zero last_process_cycles; ambiguous reset/wrap evidence')
        is_new = self.previous is None or frame_id != self.previous['completed_frame_id']
        missing = None
        if self.previous is not None:
            if frame_id < self.previous['completed_frame_id']:
                raise ValueError('Completed FrameID moved backward or rolled over')
            if not is_new and cycles != self.previous['last_process_cycles_raw']:
                raise ValueError('Same completed_frame_id has inconsistent last_process_cycles')
            if processed_delta is None:
                raise ValueError('Service samples require checked processed delta')
            if (is_new and processed_delta == 0) or (not is_new and processed_delta != 0):
                raise ValueError('Completed FrameID/processed counter consistency mismatch')
            # Source IDs advance on grant and are not replayed. Within this
            # non-wrapping epoch there cannot be more completed jobs than the
            # completed-ID advance. The difference is NOT a camera-drop count.
            if processed_delta > frame_id - self.previous['completed_frame_id']:
                raise ValueError('Processed delta exceeds completed FrameID advance')
            missing = processed_delta - int(is_new)
            self.missing_completions += missing
            self.observed_interval_completions += int(is_new)
        if is_new:
            self.samples.append({
                'CompletedFrameID': frame_id,
                'ParameterIDHex': snapshot['ParamIDHex'],
                'Mode': snapshot['completed_mode'],
                'LastProcessCyclesRaw': cycles,
                'DurationMillisecondsNominalIfNoWrap': cycles * 1000 / self.core_hz,
                'RawCyclesStrictlyBelowReferenceBudget': cycles < self.budget,
                'FirstObservedTicket': snapshot['Ticket'],
                'LastObservedTicket': snapshot['Ticket'],
                'SnapshotObservations': 1,
                'BaselineSampleBeforeFirstWindow': self.previous is None,
            })
        else:
            self.samples[-1]['LastObservedTicket'] = snapshot['Ticket']
            self.samples[-1]['SnapshotObservations'] += 1
            self.repeated_observations += 1
        self.previous = snapshot
        return {
            'NewCompletedFrameSampleID': frame_id if is_new else None,
            'RepeatedLastCompletionObservation': not is_new,
            'CompletionsWithoutCycleSamplesInWindow': missing,
            'SnapshotStateFlagsLow8': snapshot['StateFlagsLow8'],
            'SnapshotFlagsAreNotDutyCycle': True,
        }

    def report(self):
        values = [s['LastProcessCyclesRaw'] for s in self.samples]
        all_below = all(value < self.budget for value in values) if values else None
        return {
            'Schema': 'RUN8_LIGHT_SERVICE_SAMPLES_1',
            'SourceField': 'PGSTAT02.last_process_cycles_raw',
            'ReferenceScanFPS': float(REFERENCE_SCAN_FPS),
            'ReferenceScanRateSource': 'user supplied comparison target; not measured by these samples',
            'ReferenceBudgetCoreCycles': float(self.budget),
            'ReferenceBudgetCoreCyclesExact': f'{self.budget.numerator}/{self.budget.denominator}',
            'Comparison': 'strictly less than nominal_core_hz / 60.01; no rounding to 60',
            'DistinctCompletedFrameSamples': len(values),
            'RepeatedSnapshotObservationsDeduplicated': self.repeated_observations,
            'ObservedIntervalCompletionsWithCycleSample': self.observed_interval_completions,
            'IntervalCompletionsWithoutCycleSample': self.missing_completions,
            'CompleteIntervalCycleSampleCoverage': self.missing_completions == 0,
            'IntervalCycleSampleCoverageFraction': (self.observed_interval_completions /
                (self.observed_interval_completions + self.missing_completions)
                if self.observed_interval_completions + self.missing_completions else None),
            'DeduplicatedSamples': self.samples,
            'ObservedUniqueSampleSummaryOnly': {
                'MinCycles': min(values) if values else None,
                'MaxCycles': max(values) if values else None,
                'MeanCycles': mean(values) if values else None,
                'MedianCycles': median(values) if values else None,
                'SamplesBelowReferenceBudget': sum(value < self.budget for value in values),
                'SamplesAtOrAboveReferenceBudget': sum(value >= self.budget for value in values),
                'AllObservedRawCycleSamplesBelowReferenceBudget': all_below,
            },
            'ConditionalInterpretation': (
                'All observed raw cycle samples are below the reference budget. This only '
                'supports these sampled completions, conditional on the nominal clock and '
                'no per-frame uint32 cycle wrap. It does not establish sustained fresh FPS.'
                if all_below else
                'At least one observed raw cycle sample meets or exceeds the reference '
                'budget. This does not identify the bottleneck or prove a whole-stream FPS cause.'
            ) if values else 'No service samples available.',
            'ServiceCounterBits': 32,
            'PerFrameServiceCounterWrapExcludedByWire': False,
            'PopulationServiceDistributionAvailable': False,
            'CumulativeBusyCyclesAvailable': False,
            'BusyDutyCycleAvailable': False,
            'BottleneckAttribution': None,
            'SustainedFreshFrameRateInferredFromSamples': False,
            'Limitations': [
                'LIGHT exposes only the latest completed frame at each snapshot, not full frame history. '
                'Polling and phase can bias which completions are sampled; deduplication does not remove that bias. '
                'For example 1 Hz polling may alias a three-fresh/one-repeat rhythm and miss slower frames. '
                'All sampled cycles below budget does not exclude unsampled slow frames or DDR delays.',
                'The first sample precedes the measured counter windows and is excluded from interval coverage. '
                'Missing cycle samples are counted from processed counter deltas, not FrameID gaps.',
                'RTL initializes cycles at source acceptance, increments while processing and latches the old '
                'cycles register on qualified completion. This includes in-processing waits; it is not pure '
                'arithmetic latency, DDR-only time, or end-to-end presentation latency.',
                'The raw service counter is uint32. No start timestamp or overflow bit is exported. '
                'Nominal duration and budget comparisons are conditional on no per-frame wrap.',
                'Current processing/read/write busy flags are instantaneous snapshots, not duty cycle. '
                'LIGHT has no cumulative busy, pending-wait or DDR-stall cycle counters.',
                'The reciprocal of presented FPS is a mean fresh-presentation interval, never a core service '
                'time. Presented FPS and sampled cycles alone cannot isolate DDR, scheduling or another cause.',
            ],
        }
