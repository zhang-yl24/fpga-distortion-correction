"""Run8 identity, strict evidence gates and sample-limited diagnostics.

All bytes are synthetic. No physical UART, FPGA, reset, KEY1 or network access.
The unchanged original AA tests are also run by unittest discovery.
"""
import copy
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib

from aa_capture import collect
from aa_measure import CORE_HZ, UINT32, WireParser, analyze, analyze_file, analyze_stream
from aa_profiles import LEGACY_PROFILE, RUN8_PROFILE, PROFILES, get_profile
from aa_protocol import make_arm, make_stats, parse
from service_diagnostics import REFERENCE_SCAN_FPS
from test_aa_tools import FakeClock, FakeTransport, ack, fixture, signature, stats


RUN8 = get_profile(RUN8_PROFILE)
LEGACY = get_profile(LEGACY_PROFILE)


def run8_fixture(**kwargs):
    raw, manifest = fixture(**kwargs)
    manifest.update(Profile=RUN8_PROFILE, LoadedBitstreamSHA256OperatorSupplied=RUN8.bitstream_sha256)
    return raw, manifest


def with_hash(raw, manifest):
    return dict(manifest, RawSHA256=hashlib.sha256(raw).hexdigest())


def mutate(packet, offset, value, fmt='<I'):
    changed = bytearray(packet)
    struct.pack_into(fmt, changed, offset, value)
    crc_offset = 80 if packet[:8] == b'PGSTAT02' else 120 if packet[:8] == b'PGSIG001' else 20
    struct.pack_into('<I', changed, crc_offset, zlib.crc32(changed[:crc_offset]))
    return bytes(changed)


def sampled_fixture(points):
    """(completed id, processed count, raw cycles, tick, repeat count, flags)."""
    _, manifest = run8_fixture()
    packets = [ack()]
    requests = [make_arm(1, 10)]
    for i, (frame, count, cycles, tick, repeats, flags) in enumerate(points):
        ticket, nonce = i + 2, (i + 2) * 10
        requests.append(make_stats(ticket, nonce))
        # Presented signatures are delivered samples, not stats endpoints.
        packets.append(signature(frame - 1 if i == 0 else frame, i + 1))
        packet = stats(ticket, nonce, i, tick, count, frame_id=frame,
                       repeats=repeats, flags=flags)
        packets.append(mutate(packet, 40, cycles))
    raw = b''.join(packets)
    manifest['Requests'] = [{'PacketHex': p.hex(), 'Outcome': 'sent'} for p in requests]
    return raw, with_hash(raw, manifest)


def measure(raw, manifest):
    return analyze(raw, manifest, profile=RUN8_PROFILE, uninterrupted_reset_epoch=True)


class Run8Tests(unittest.TestCase):
    def reject(self, raw, manifest, message='.'):
        with self.assertRaisesRegex(ValueError, message):
            measure(raw, with_hash(raw, manifest))

    def test_valid_run8_has_explicit_profile_and_no_hardware_claim(self):
        raw, manifest = run8_fixture()
        result = measure(raw, manifest)
        self.assertEqual(result['Profile'], RUN8_PROFILE)
        self.assertEqual(result['Schema'], 'RUN8_MEASUREMENT_1')
        self.assertEqual(result['ParameterIDHex'], 'adfb7264')
        self.assertFalse(result['BitstreamIdentityAuthenticatedByWire'])
        self.assertFalse(result['HardwarePassClaim'])
        self.assertFalse(result['Sustained60FPSPassClaim'])
        self.assertFalse(result['InputCameraFPSMeasured'])
        self.assertFalse(result['ZeroDroppedCounterProvesNoInputLoss'])
        self.assertIn('source_valid && source_ready', result['CounterFieldSemantics']['captured_frames'])
        self.assertIn('NOT total', result['CounterFieldSemantics']['dropped_frames'])
        for counter in ('captured', 'processed', 'presented', 'scan_repeat', 'dropped'):
            self.assertIn(counter + '_fps_nominal', result['Windows'][0]['Rates'])
            self.assertIn(counter + '_frames', result['Windows'][0]['Delta'])

    def test_old_sha_is_rejected_under_run8_even_with_shared_parameter_tag(self):
        raw, manifest = run8_fixture()
        manifest['LoadedBitstreamSHA256OperatorSupplied'] = LEGACY.bitstream_sha256
        self.reject(raw, manifest, 'bitstream SHA256')

    def test_new_sha_is_rejected_under_default_and_explicit_legacy(self):
        raw, manifest = fixture()
        manifest['LoadedBitstreamSHA256OperatorSupplied'] = RUN8.bitstream_sha256
        for kwargs in ({}, {'profile': LEGACY_PROFILE}):
            with self.subTest(kwargs=kwargs), self.assertRaisesRegex(ValueError, 'bitstream SHA256'):
                analyze(raw, manifest, uninterrupted_reset_epoch=True, **kwargs)

    def test_run8_is_never_auto_selected_from_manifest(self):
        raw, manifest = run8_fixture()
        with self.assertRaisesRegex(ValueError, 'Profile'):
            analyze(raw, manifest, uninterrupted_reset_epoch=True)
        del manifest['Profile']
        self.reject(raw, manifest, 'Profile')
        manifest['Profile'] = LEGACY_PROFILE
        self.reject(raw, manifest, 'Profile')

    def test_profile_registry_does_not_allow_arbitrary_sha_or_policy_objects(self):
        with self.assertRaises(TypeError):
            PROFILES['anything'] = RUN8
        for name in ('062c79b7', 'custom', RUN8, None):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'Unknown profile'):
                get_profile(name)
        for sha in ('0' * 64, RUN8.bitstream_sha256[:8], RUN8.bitstream_sha256 + '00'):
            raw, manifest = run8_fixture()
            manifest['LoadedBitstreamSHA256OperatorSupplied'] = sha
            self.reject(raw, manifest, 'bitstream SHA256')

    def test_old_profile_default_retains_legacy_output(self):
        raw, manifest = fixture()
        result = analyze(raw, manifest, uninterrupted_reset_epoch=True)
        self.assertEqual(result['Schema'], 'AA_MEASUREMENT_2')
        self.assertNotIn('ServiceDiagnostics', result)
        self.assertEqual(result, analyze(raw, manifest, profile=LEGACY_PROFILE,
                                        uninterrupted_reset_epoch=True))

    def test_crc_corruption_of_each_packet_kind_fails(self):
        raw, manifest = run8_fixture()
        for packet_offset in (0, 24, 152):
            bad = bytearray(raw)
            bad[packet_offset + 12] ^= 1
            self.reject(bytes(bad), manifest)

    def test_known_boundary_and_truncation_not_resynchronized(self):
        raw, manifest = run8_fixture()
        self.reject(b'junk' + raw, manifest, 'Unknown packet boundary')
        self.reject(raw[:-1], manifest, 'Truncated')
        parser = WireParser(profile=RUN8_PROFILE)
        rows = []
        for byte in raw:
            rows += parser.feed(bytes([byte]))
        parser.finish()
        self.assertEqual(rows, parse(raw, profile=RUN8_PROFILE))

    def test_wrong_raw_hash_late_fails_and_file_is_unchanged(self):
        raw, manifest = run8_fixture()
        manifest['RawSHA256'] = '0' * 64
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'raw'
            path.write_bytes(raw)
            with self.assertRaisesRegex(ValueError, 'SHA256'):
                analyze_file(path, manifest, profile=RUN8_PROFILE, uninterrupted_reset_epoch=True)
            self.assertEqual(path.read_bytes(), raw)

    def test_ack_nonce_status_ticket_epoch_and_signature_session_gates(self):
        raw, manifest = run8_fixture()
        for altered in (ack(nonce=11) + raw[24:], ack(ticket=2) + raw[24:],
                        ack(status=0) + raw[24:], raw + ack(),
                        raw[:24] + signature(99, 1, nonce=999) + raw[152:]):
            self.reject(altered, manifest)
        # Epoch authenticity is not on-wire proven: operator attestation remains mandatory.
        with self.assertRaisesRegex(ValueError, 'Operator must confirm'):
            analyze(raw, manifest, profile=RUN8_PROFILE)
        for key, value in (('KnownCleanResetBoundaryAttested', False), ('EpochLabel', ''),
                           ('Status', 'failed'), ('KnownCleanResetBoundaryAttested', 'yes'),
                           ('EpochLabel', ' ')):
            changed = dict(manifest, **{key: value})
            self.reject(raw, changed)

    def test_stats_nonce_duplicates_missing_and_request_crc(self):
        raw, manifest = run8_fixture()
        for changed in (raw[:-84] + mutate(raw[-84:], 16, 999), raw + raw[-84:], raw[:-84]):
            self.reject(changed, manifest, 'statistics response')
        for request_index, change in (
            (1, {'Outcome': 'pending'}),
            (1, {'PacketHex': make_stats(2, 10).hex()}),
            (2, {'PacketHex': make_stats(1, 30).hex()}),
            (2, {'PacketHex': (make_stats(3, 30)[:-1] + b'X').hex()}),
        ):
            changed = copy.deepcopy(manifest)
            changed['Requests'][request_index].update(change)
            self.reject(raw, changed)

    def test_stats_parameter_mode_clock_and_invalid_completion_gates(self):
        raw, manifest = run8_fixture()
        for offset, value in ((48, 0), (52, 0), (52, 3), (24, 124999999),
                              (24, 0), (44, 0), (40, 0), (20, 6), (20, 15)):
            with self.subTest(offset=offset, value=value):
                self.reject(raw[:-84] + mutate(raw[-84:], offset, value), manifest)

    def test_signature_parameter_mode_and_complete_geometry_gates(self):
        raw, manifest = run8_fixture()
        for offset, value, fmt in ((28, 1, '<I'), (61, 0, '<B'), (61, 3, '<B'),
                                   (56, 1280, '<H'), (36, 100, '<I'), (60, 0, '<B')):
            changed = raw[:24] + mutate(raw[24:152], offset, value, fmt) + raw[152:]
            self.reject(changed, manifest)

    def test_fault_detail_preserved_and_rejected(self):
        for flags in (64, 1 << 8, 1 << 16, 1 << 24):
            raw, manifest = run8_fixture(flags=flags)
            self.reject(raw, manifest, 'Fault detail')

    def test_reset_tick_sequence_frame_and_impossible_counter_deltas(self):
        raw, manifest = run8_fixture()
        for offset, value, fmt in ((32, CORE_HZ, '<Q'), (32, 1, '<Q'),
                                  (32, CORE_HZ + UINT32, '<Q'), (28, 0, '<I'),
                                  (44, 1, '<I'), (60, 0, '<I')):
            self.reject(raw[:-84] + mutate(raw[-84:], offset, value, fmt), manifest)
        for tail in (signature(1, 4), signature(160, 1)):
            self.reject(raw + tail, manifest)

    def test_latest_completion_samples_are_deduplicated_not_snapshot_weighted(self):
        raw, manifest = sampled_fixture([
            (100, 100, 1_500_000, CORE_HZ, 0, 2),
            (100, 100, 1_500_000, 2*CORE_HZ, 60, 2),
            (102, 102, 2_000_000, 3*CORE_HZ, 118, 0),
        ])
        result = measure(raw, manifest)
        service = result['ServiceDiagnostics']
        self.assertEqual(service['DistinctCompletedFrameSamples'], 2)
        self.assertEqual(service['RepeatedSnapshotObservationsDeduplicated'], 1)
        self.assertEqual(service['DeduplicatedSamples'][0]['SnapshotObservations'], 2)
        self.assertEqual(service['ObservedUniqueSampleSummaryOnly']['MeanCycles'], 1_750_000)
        self.assertEqual(service['IntervalCompletionsWithoutCycleSample'], 1)
        self.assertFalse(service['CompleteIntervalCycleSampleCoverage'])
        self.assertEqual(result['Windows'][0]['ServiceObservation']['NewCompletedFrameSampleID'], None)
        self.assertEqual(result['Windows'][1]['ServiceObservation']['CompletionsWithoutCycleSamplesInWindow'], 1)
        self.assertFalse(service['BusyDutyCycleAvailable'])

    def test_same_completed_id_with_changed_cycle_count_is_rejected(self):
        raw, manifest = sampled_fixture([
            (100, 100, 1_500_000, CORE_HZ, 0, 0),
            (100, 100, 1_500_001, 2*CORE_HZ, 60, 0),
        ])
        self.reject(raw, manifest, 'inconsistent last_process_cycles')

    def test_completed_id_and_counter_contradictions_are_rejected(self):
        for frame, count in ((100, 101), (101, 100)):
            raw, manifest = sampled_fixture([
                (100, 100, 1_000, CORE_HZ, 0, 0),
                (frame, count, 1_000, 2*CORE_HZ, 0, 0),
            ])
            self.reject(raw, manifest, 'consistency mismatch')

    def test_processed_delta_cannot_exceed_completed_id_advance(self):
        raw, manifest = sampled_fixture([
            (100, 100, 1_000_000, CORE_HZ, 0, 0),
            (101, 160, 1_100_000, 2*CORE_HZ, 0, 0),
        ])
        self.reject(raw, manifest, 'Processed delta exceeds completed FrameID advance')

    def test_id_gaps_are_not_counted_as_missing_service_samples(self):
        raw, manifest = sampled_fixture([
            (100, 100, 1_000_000, CORE_HZ, 0, 0),
            (110, 101, 1_100_000, 2*CORE_HZ, 59, 0),
        ])
        service = measure(raw, manifest)['ServiceDiagnostics']
        self.assertEqual(service['IntervalCompletionsWithoutCycleSample'], 0)
        self.assertEqual(service['ObservedIntervalCompletionsWithCycleSample'], 1)
        self.assertTrue(service['CompleteIntervalCycleSampleCoverage'])
        self.assertFalse(service['PopulationServiceDistributionAvailable'])

    def test_budget_uses_exact_6001_over_100_and_strict_comparison(self):
        budget = CORE_HZ / REFERENCE_SCAN_FPS
        floor = budget.numerator // budget.denominator
        raw, manifest = sampled_fixture([
            (100, 100, floor, CORE_HZ, 0, 0),
            (101, 101, floor + 1, 2*CORE_HZ, 59, 0),
        ])
        service = measure(raw, manifest)['ServiceDiagnostics']
        self.assertEqual(service['ReferenceBudgetCoreCyclesExact'], '12500000000/6001')
        self.assertTrue(service['DeduplicatedSamples'][0]['RawCyclesStrictlyBelowReferenceBudget'])
        self.assertFalse(service['DeduplicatedSamples'][1]['RawCyclesStrictlyBelowReferenceBudget'])
        self.assertFalse(service['ObservedUniqueSampleSummaryOnly']['AllObservedRawCycleSamplesBelowReferenceBudget'])
        self.assertFalse(service['PerFrameServiceCounterWrapExcludedByWire'])

    def test_4496_presented_fps_is_not_used_as_service_time_or_causal_claim(self):
        raw, manifest = sampled_fixture([
            (100, 100, 1_500_000, CORE_HZ, 0, 2),
            (1224, 1224, 1_500_000, 26*CORE_HZ, 376, 2),
        ])
        result = measure(raw, manifest)
        self.assertEqual(result['Rates']['presented_fps_nominal'], 44.96)
        service = result['ServiceDiagnostics']
        for sample in service['DeduplicatedSamples']:
            self.assertEqual(sample['DurationMillisecondsNominalIfNoWrap'], 12)
            self.assertNotAlmostEqual(sample['DurationMillisecondsNominalIfNoWrap'], 1000/44.96)
        self.assertTrue(service['ObservedUniqueSampleSummaryOnly']['AllObservedRawCycleSamplesBelowReferenceBudget'])
        self.assertEqual(service['IntervalCompletionsWithoutCycleSample'], 1123)
        self.assertEqual(service['IntervalCycleSampleCoverageFraction'], 1/1124)
        self.assertIn('1 Hz polling may alias', ' '.join(service['Limitations']))
        self.assertIsNone(service['BottleneckAttribution'])
        self.assertFalse(service['SustainedFreshFrameRateInferredFromSamples'])
        self.assertFalse(service['CumulativeBusyCyclesAvailable'])

    def test_same_counters_different_cycles_keep_fps_unchanged(self):
        outputs = []
        for cycles in (1_000_000, 3_000_000):
            raw, manifest = sampled_fixture([
                (100, 100, cycles, CORE_HZ, 0, 0),
                (145, 145, cycles, 2*CORE_HZ, 15, 0),
            ])
            outputs.append(measure(raw, manifest))
        self.assertEqual(outputs[0]['Rates'], outputs[1]['Rates'])
        self.assertNotEqual(outputs[0]['ServiceDiagnostics']['ObservedUniqueSampleSummaryOnly'],
                            outputs[1]['ServiceDiagnostics']['ObservedUniqueSampleSummaryOnly'])

    def test_streaming_short_reads_match_bytes_result(self):
        raw, manifest = run8_fixture()
        class ShortStream:
            source = io.BytesIO(raw)
            def read(self, size):
                return self.source.read(min(size, 3))
        self.assertEqual(analyze_stream(ShortStream(), manifest, profile=RUN8_PROFILE,
                                       uninterrupted_reset_epoch=True), measure(raw, manifest))

    def test_fake_collector_run8_to_analyzer_and_raw_manifest_identity(self):
        _, manifest = run8_fixture()
        clock = FakeClock()
        transport = FakeTransport(clock, extra_tail=True)
        nonces = iter(range(100, 1000))
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / 'capture'
            saved = collect(transport, folder, manifest, profile=RUN8_PROFILE,
                            seconds=1, interval=.25, clock=clock, nonce_source=lambda: next(nonces))
            result = analyze_file(folder / 'camera-uart.raw.bin', saved, profile=RUN8_PROFILE,
                                  uninterrupted_reset_epoch=True)
            self.assertEqual(saved['Profile'], RUN8_PROFILE)
            self.assertTrue(result['EvidenceAcceptedForCalculation'])
            self.assertGreater(result['ServiceDiagnostics']['DistinctCompletedFrameSamples'], 1)
            self.assertEqual(saved['UnfinishedTailBytes'], 0)
            self.assertEqual(len(saved['Requests']), len(transport.commands))

    def test_collector_rejects_identity_or_boundary_before_any_write(self):
        _, manifest = run8_fixture()
        cases = [dict(manifest, LoadedBitstreamSHA256OperatorSupplied=LEGACY.bitstream_sha256),
                 dict(manifest, Profile=LEGACY_PROFILE),
                 dict(manifest, KnownCleanResetBoundaryAttested=False),
                 dict(manifest, EpochLabel=' '), dict(manifest, ExpectedMode='gamma')]
        for changed in cases:
            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / 'must-not-exist'
                with self.assertRaises(ValueError):
                    collect(None, path, changed, profile=RUN8_PROFILE)
                self.assertFalse(path.exists())

    def test_collector_partial_corrupt_and_timeout_preserve_evidence_no_retry(self):
        for options, error in (({'partial': True}, ValueError), ({'corrupt': True}, ValueError),
                                ({'silent': True}, TimeoutError)):
            _, manifest = run8_fixture()
            clock = FakeClock()
            transport = FakeTransport(clock, **options)
            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / 'capture'
                with self.assertRaises(error):
                    collect(transport, path, manifest, profile=RUN8_PROFILE, seconds=1,
                            interval=.25, arm_timeout=.5, clock=clock)
                saved = json.loads((path / 'capture.json').read_text())
                self.assertEqual(saved['Status'], 'failed')
                self.assertEqual(len(transport.commands), 1)
                self.assertFalse(saved['HardwarePassClaim'])

    def test_cli_profile_guards_before_serial_import_with_sentinel(self):
        script = str(Path(__file__).with_name('aa_capture.py'))
        base = [sys.executable, script, '--port', 'NEVER_OPEN', '--epoch-label', 'synthetic',
                '--mode', 'corr', '--confirm-clean-reset-boundary']
        for sha, profile in ((RUN8.bitstream_sha256, []),
                             (LEGACY.bitstream_sha256, ['--profile', RUN8_PROFILE]),
                             (RUN8.bitstream_sha256, ['--profile', LEGACY_PROFILE])):
            with tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp) / 'must-not-exist'
                run = subprocess.run(base + ['--out-dir', str(out), '--loaded-bitstream-sha256', sha]
                                     + profile, capture_output=True, text=True)
                self.assertEqual(run.returncode, 2)
                self.assertIn('SHA256 must exactly match', run.stderr)
                self.assertNotIn('pyserial', run.stderr)
                self.assertFalse(out.exists())

    def test_cli_run8_analyzer_succeeds_only_when_explicit(self):
        script = str(Path(__file__).with_name('aa_measure.py'))
        raw, manifest = run8_fixture()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            (path / 'camera-uart.raw.bin').write_bytes(raw)
            (path / 'capture.json').write_text(json.dumps(manifest))
            base = [sys.executable, script, str(path), '--confirm-uninterrupted-epoch']
            failed = subprocess.run(base, capture_output=True, text=True)
            self.assertEqual(failed.returncode, 2)
            passed = subprocess.run(base + ['--profile', RUN8_PROFILE], capture_output=True, text=True)
            self.assertEqual(passed.returncode, 0, passed.stderr)
            self.assertEqual(json.loads(passed.stdout)['Profile'], RUN8_PROFILE)


if __name__ == '__main__':
    unittest.main(verbosity=2)
