"""New image's slot extension. All capture bytes are synthetic unless marked replay."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib

from aa_capture import collect
from aa_measure import WireParser, analyze
from aa_profiles import LEGACY_PROFILE, RUN8_PROFILE, SLOT2_PROFILE, PROFILES, get_profile
from aa_protocol import parse
from test_aa_tools import FakeClock, FakeTransport, fixture, signature
from test_run8 import mutate


NEW = get_profile(SLOT2_PROFILE)


def slot_packet(packet, slot):
    return mutate(packet, 15, slot, '<B')


def slot_fixture(slots=(0, 1, 2)):
    raw, manifest = fixture()
    rows = parse(raw)
    pieces = []
    i = 0
    for row in rows:
        off = row['Offset']
        size = {'SGK1': 24, 'PGSTAT02': 84, 'PGSIG001': 128}[row['Kind']]
        p = raw[off:off + size]
        if row['Kind'] == 'PGSIG001':
            p = slot_packet(p, slots[i % len(slots)])
            i += 1
        pieces.append(p)
    raw = b''.join(pieces)
    manifest.update(Profile=SLOT2_PROFILE,
                    LoadedBitstreamSHA256OperatorSupplied=NEW.bitstream_sha256,
                    RawSHA256=hashlib.sha256(raw).hexdigest())
    return raw, manifest


class Slot2Tests(unittest.TestCase):
    def test_closed_exact_identity(self):
        self.assertEqual(NEW.result_slots, 3)
        self.assertEqual(NEW.bitstream_sha256,
                         '9abf8895212af90b5c55c7fcdc442c6a75cc425187be69a8511bbd16aff6663a')
        self.assertEqual((NEW.parameter_id, NEW.core_hz), (0xadfb7264, 125000000))
        with self.assertRaises(TypeError):
            PROFILES['custom'] = NEW

    def test_full_byte15_domain_for_all_profiles(self):
        for name, p in PROFILES.items():
            for slot in range(256):
                packet = slot_packet(signature(100, 1), slot)
                with self.subTest(profile=name, slot=slot):
                    if slot < p.result_slots:
                        self.assertEqual(parse(packet, profile=name)[0]['Decoded']['Bank'], slot)
                    else:
                        with self.assertRaisesRegex(ValueError, 'result slot'):
                            parse(packet, profile=name)

    def test_slot2_is_not_bank_zero_and_old_parser_rejects(self):
        packet = slot_packet(signature(100, 1), 2)
        d = parse(packet, profile=SLOT2_PROFILE)[0]['Decoded']
        self.assertEqual((d['Bank'], d['ResultSlot']), (2, 2))
        for kwargs in ({}, {'profile': LEGACY_PROFILE}, {'profile': RUN8_PROFILE}):
            with self.assertRaisesRegex(ValueError, 'result slot'):
                parse(packet, **kwargs)

    def test_full_measurement_keeps_slots_and_false_hardware_claims(self):
        raw, m = slot_fixture()
        r = analyze(raw, m, profile=SLOT2_PROFILE, uninterrupted_reset_epoch=True)
        self.assertEqual(r['Schema'], 'RUN8_SLOT2_MEASUREMENT_1')
        self.assertEqual(r['ResultSlotDiagnostics']['ObservedLogicalResultSlots'], [0, 1, 2])
        self.assertTrue(r['ResultSlotDiagnostics']['Slot2SignatureObserved'])
        self.assertFalse(r['HardwarePassClaim'])
        self.assertFalse(r['Sustained60FPSPassClaim'])
        self.assertFalse(r['BitstreamIdentityAuthenticatedByWire'])

    def test_no_slot2_seen_is_reported_not_invented(self):
        raw, m = slot_fixture((0, 1))
        r = analyze(raw, m, profile=SLOT2_PROFILE, uninterrupted_reset_epoch=True)
        self.assertFalse(r['ResultSlotDiagnostics']['Slot2SignatureObserved'])

    def test_profile_and_sha_cross_product(self):
        raw, m = slot_fixture((0, 1))
        for name, p in PROFILES.items():
            for recorded_name in PROFILES:
                for sha_p in PROFILES.values():
                    mm = dict(m, Profile=recorded_name,
                              LoadedBitstreamSHA256OperatorSupplied=sha_p.bitstream_sha256)
                    with self.subTest(name=name, recorded=recorded_name, sha=sha_p.name):
                        if recorded_name == name and sha_p.name == name:
                            analyze(raw, mm, profile=name, uninterrupted_reset_epoch=True)
                        else:
                            with self.assertRaises(ValueError):
                                analyze(raw, mm, profile=name, uninterrupted_reset_epoch=True)

    def test_no_profile_guess_from_static_param_tag(self):
        raw, m = slot_fixture((0, 1))
        for change in ({}, {'Profile': RUN8_PROFILE}, {'Profile': None}):
            mm = dict(m, **change)
            with self.assertRaises(ValueError):
                analyze(raw, mm, uninterrupted_reset_epoch=True)

    def test_byte15_remains_crc_covered(self):
        p = bytearray(signature(100, 1))
        p[15] = 2
        with self.assertRaises(ValueError):
            parse(bytes(p), profile=SLOT2_PROFILE)

    def test_incremental_no_resynchronization(self):
        raw, _ = slot_fixture()
        p = WireParser(profile=SLOT2_PROFILE)
        rows = []
        for b in raw:
            rows.extend(p.feed(bytes([b])))
        p.finish()
        self.assertEqual(rows, parse(raw, profile=SLOT2_PROFILE))
        with self.assertRaises(ValueError):
            parse(b'X' + raw, profile=SLOT2_PROFILE)

    def test_prior_rtl_packet_replay_not_board_or_1080p(self):
        for slot in (0, 1, 2):
            path = Path(__file__).resolve().parents[1] / 'evidence/rtl_packet_replay' / f'slot{slot}.hex'
            packet = bytes.fromhex(path.read_text().strip())
            d = parse(packet, profile=SLOT2_PROFILE)[0]['Decoded']
            self.assertEqual((d['Bank'], d['ResultSlot']), (slot, slot))
            self.assertEqual(d['PixelCRC'], 0xb9c1c2c2)
            self.assertEqual((d['Width'], d['Height']), (4, 4))
            self.assertFalse(d['Complete1080'])

    def test_fake_collector_and_offline_acceptance_new_profile(self):
        clock = FakeClock()
        t = FakeTransport(clock)
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp) / 'capture'
            manifest = {'Profile': SLOT2_PROFILE, 'LoadedBitstreamSHA256OperatorSupplied': NEW.bitstream_sha256,
                        'KnownCleanResetBoundaryAttested': True, 'EpochLabel': 'fake-only', 'ExpectedMode': 'corr'}
            m = collect(t, directory, manifest, profile=SLOT2_PROFILE, clock=clock, seconds=1,
                        interval=.25, nonce_source=iter(range(1, 100)).__next__)
            r = analyze((directory / 'camera-uart.raw.bin').read_bytes(), m,
                        profile=SLOT2_PROFILE, uninterrupted_reset_epoch=True)
            self.assertEqual(r['Profile'], SLOT2_PROFILE)
            self.assertFalse(r['HardwarePassClaim'])

    def test_wrong_old_sha_cli_rejects_before_serial_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            # If validation reaches import serial, the sentinel text leaks.
            Path(tmp, 'serial.py').write_text("raise RuntimeError('SERIAL_IMPORT_FORBIDDEN')\n")
            import os
            e = dict(os.environ, PYTHONPATH=tmp, PYTHONDONTWRITEBYTECODE='1')
            r = subprocess.run([sys.executable, str(Path(__file__).with_name('aa_capture.py')),
                '--profile', SLOT2_PROFILE, '--port', 'NOT_A_REAL_DEVICE', '--out-dir', str(Path(tmp)/'out'),
                '--epoch-label', 'test', '--mode', 'corr', '--confirm-clean-reset-boundary',
                '--loaded-bitstream-sha256', get_profile(RUN8_PROFILE).bitstream_sha256],
                text=True, capture_output=True, env=e)
            self.assertNotEqual(r.returncode, 0)
            self.assertIn('Bitstream SHA256', r.stderr)
            self.assertNotIn('SERIAL_IMPORT_FORBIDDEN', r.stderr)


if __name__ == '__main__':
    unittest.main()
