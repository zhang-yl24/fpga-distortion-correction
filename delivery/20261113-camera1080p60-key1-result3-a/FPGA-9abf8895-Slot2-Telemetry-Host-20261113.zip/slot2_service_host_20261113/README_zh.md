# 9abf8895 实验位流专用 slot2 遥测工具

本包只包含主机工具和核对证据，不包含位流，不修改 FPGA。已做离线 Python 测试，未连接 UART、复位板卡、操作 KEY1 或实板测帧。它解决新版本遥测的准确采集/解释，不代表 60 个新画面/秒已经实现。

唯一新 profile：`run8-elastic-result3-slot2-9abf8895`

唯一配套 sbit SHA256：

`9abf8895212af90b5c55c7fcdc442c6a75cc425187be69a8511bbd16aff6663a`

旧 062c79b7、旧 AA 1665586d 仍是独立 profile，不能混用。没有按 wire 参数标签自动猜版本的功能。默认仍是旧 AA，因此本次必须明确写新 profile。

## 同学操作步骤（Windows、macOS、Linux 均可）

需要 Python 3.10+。Windows 如使用 `py -3`，把下文全部 `python` 一致替换为 `py -3`。在本包根目录执行命令。采集需要 pyserial，已安装则不用重复安装；离线解码和测试不需要第三方包。

1. 先核对准备使用的本地 sbit 文件。把路径改成实际收到的文件：

`python host/check_bitstream.py "路径/aa-result3-camera1080p60-key1-9abf8895.sbit"`

必须输出 `LocalFileSHA256Matches: true`。这只检查磁盘文件，不能确认 FPGA 当前加载了什么。操作者仍须确认下载的是该文件，不能给旧位流填新 SHA。

2. 检查工具本身，运行纯离线测试：

`python run_validation.py`

应看到全部 66 项通过。仅实际串口采集需要 `python -m pip install pyserial`。本包不会自动安装或打开串口。

3. 关闭其他串口监视器，使用操作者确认的端口（如 COM5）。为每次采集建立一次外部干净复位/安静包边界，在发起遥测 ARM 前通过 KEY1 选定所需 RAW 或 CORR，之后保持模式稳定。程序不复位、不烧写、不切 KEY1、不扫描端口、不清空接收缓存。`--confirm-clean-reset-boundary` 是操作者确认，不是软件复位指令。USB 串口驱动可能改变控制线，软件不能保证物理复位行为。

4. 采集 CORR 60 秒。以下为单行命令，把 COM5、epoch 标签和输出目录按实际情况填写，输出目录必须不存在：

`python host/aa_capture.py --profile run8-elastic-result3-slot2-9abf8895 --port COM5 --out-dir slot2_corr_01 --epoch-label board_corr_reset01 --mode corr --loaded-bitstream-sha256 9abf8895212af90b5c55c7fcdc442c6a75cc425187be69a8511bbd16aff6663a --confirm-clean-reset-boundary --seconds 60 --stats-interval 0.271`

0.271 秒是现有工具支持的显式轮询间隔，用来降低恰好 1 Hz 与“三新一重”节律锁相的风险，不保证采样无偏或覆盖每帧。协议、波特率和每帧签名流均未改变。

5. 仅在操作者独立确认整个采集期间没有 FPGA 复位、KEY1 模式变化后，离线分析：

`python host/aa_measure.py slot2_corr_01 --profile run8-elastic-result3-slot2-9abf8895 --confirm-uninterrupted-epoch > slot2_corr_01_report.json`

如需 RAW 对照，另建一次干净复位边界、设定 RAW，使用新输出目录/epoch，并把 `--mode corr` 改成 `--mode raw`。不要在一个采集窗口内切 KEY1，也不要直接接着重复 ARM。失败或超时应保留原始数据和错误，不要改 manifest 凑通过。

6. 回传整份采集目录（含 `capture.json`、`camera-uart.raw.bin`）和报告 JSON。另说明实际加载的 sbit SHA、RAW/CORR 和板上现象。目录名本身不能证明版本或模式。

## 看哪些结果

- `Rates.presented_fps_nominal`：新呈现画面率。`processed_fps_nominal` 是处理完成率；两者不要与屏幕扫描 Hz 混为一谈。
- `Rates.scan_repeat_fps_nominal`：重复呈现计数率。它与新呈现之和也不无条件等于物理扫描频率，因为 LIGHT 没有导出空白/失败扫描。
- `ResultSlotDiagnostics.ObservedLogicalResultSlots`：实际收到的签名中的逻辑结果槽，应只出现 0、1、2；`Slot2SignatureObserved` 明确标记是否看到 2。没有看到 slot2 会如实记录，不会伪造“第三槽验证通过”。收到 3 或任何更高字节值会拒绝。
- `ServiceDiagnostics`：仅对已采到的最近完成帧的处理周期去重统计。它不是全部帧的 p95/平均耗时，不可用“样本都低于预算”证明 DDR 或 60 帧已通过。其 60.01 比较值来自此前用户提供的扫描观测，是固定参照，非本次工具测得的 HDMI 频率。
- `captured_frames` 的旧 wire 名实际表示 source descriptor 被处理 owner 接受，不是相机所有 VSYNC/捕获数。`dropped_frames=0` 也不能排除未获空闲 source bank 的输入帧。不要据此把约 45/s 定为相机只有 45fps。

解析检查完整文件 SHA、CRC、包边界、ARM/请求 nonce、session、参数、模式、标称时钟、故障、帧序及计数一致性。不搜索 magic 重同步、不截断 slot 高位、不放宽旧版本检查。板卡 wire 共享静态参数标签 adfb7264，不认证位流身份；profile/SHA 是操作者提供并与本包固定身份比对的约束。

## 源码和验证边界

实际新包 `delivery-20261113-result3-a.zip` SHA256 `0a50c07a6cc127e186eeea80188cb5b1356d881894c8a06b2569c982f9e67557`；source commit `22d5b2bc09c0013939de57d47436405a380bb5fd`，handoff commit `ff646832abfebe75bd940024ca7558c03c844580`。已核新包 37 个 manifest 项及 sbit，使用真实公开 recipe 对已存 164-file 基线重建校验 174 个 native 文件、97 个 payload hash。新 top hash `caa393c6d4aa55a46442b85c96b0acf5b2a8a65bf59134d6a7350f4dd882ffc1`。

新 top 固定三结果槽、GammaOFF、Brown、runtime rotation OFF、STATS ON、标称 core125MHz。PGSIG001仍128字节，byte15零扩展整字节表示逻辑结果槽；SGK1仍24字节；PGSTAT02仍84字节、LIGHT/FAULT_DETAIL。它不是物理 DDR plane 编号或 source bank 编号。

详细身份和13个相关源码在 `evidence/`。其中 `rtl_packet_replay/` 是此前同源码 4×4 小帧仿真的留存字节，本次只离线重放解码，不能当作新跑 1080p、实板或持续 60fps 证据。Python synthetic/fake transport 测试亦不是硬件结果。本任务未独立综合/布线或证明 RTL 到 bitstream 的网表等价，也未读回 FPGA 身份。
