`timescale 1ns/1ps
// Experimental scatter8 core. Two 32-bit even/odd true-dual-port banks
// replace two 16-bit banks at half the depth. Storage bits and cache tags
// are unchanged. Two writes per bank scatter eight pixels per edge, so
// every validated 128-pixel fill uses sixteen exclusive SCATTER edges.
// The extra halfword select is registered with the existing query stage.
// RAM inference, physical resources and timing require main's PDS review.
module ddr_compact_neighbour_cache_core_scatter8_tag_prefetch_local #(
    parameter WIDTH=640,HEIGHT=480,TAG_W=24,INDEX_BITS=3,TIMEOUT_BITS=26
)(
    input clk,rst_n,
    input frame_valid,output wire frame_ready,input [27:0] frame_base,
    input in_valid,output wire in_ready,input signed [23:0] in_x,in_y,
    input [TAG_W-1:0] in_tag,
    output wire out_valid,input out_ready,output wire [23:0] p00,p10,p01,p11,
    output wire [7:0] fx,fy,output wire [TAG_W-1:0] out_tag,
    output wire [27:0] araddr,output wire [3:0] arlen,output wire arvalid,input arready,
    input [255:0] rdata,input rvalid,rlast,input [3:0] rid,
    output reg failed,output reg [7:0] fault,
    output wire [31:0] hits,misses,completed_queries
);
    localparam LINES=1<<INDEX_BITS,ADDRESS_BITS=INDEX_BITS+5;
    localparam IDLE=0,SELECT=1,AR=2,FILL=3,SCATTER=4,LOAD=5,PICK=6,RESULT=7,FAULT=8,CHECK=9;
    reg [3:0] state;
    reg frame_loaded,address_pending;
    reg [27:0] base;
    reg [LINES-1:0] valid_lines;
    reg [24:0] tags[0:LINES-1];
    reg signed [16:0] slow_x,slow_y;
    reg [1:0] neighbour;
    reg [7:0] slow_fx,slow_fy;
    reg [TAG_W-1:0] slow_tag;
    reg [23:0] slow_pixel[0:3];
    reg [24:0] selected_block;
    reg [INDEX_BITS-1:0] selected_line;
    reg [ADDRESS_BITS-1:0] selected_pixel_address;
    reg selected_parity,selected_lane;
    reg [2:0] fill_beat;
    reg [3:0] scatter_group;
    (* ram_style="registers" *) reg [255:0] fill_buffer[0:7];
    reg [TIMEOUT_BITS-1:0] watchdog;
    reg [31:0] hit_count,miss_count,complete_count;
    reg v0,v1;
    reg [3:0] bounds0,parity0,lane0;
    reg [7:0] fx0,fy0,fx1,fy1;
    reg [TAG_W-1:0] tag0,tag1;
    reg [23:0] fast_pixel[0:3];
    reg query_valid;
    reg signed [16:0] query_x,query_y;
    reg [7:0] query_fx,query_fy;
    reg [TAG_W-1:0] query_tag;
    reg [3:0] in_bounds;
    reg [31:0] pixel_number[0:3];
    // Private samples belong to the existing registered decoded head.
    // query_valid gates observation; reset/frame acceptance never publishes
    // an uninitialized sample. Four25-bit tags + four validity bits =104bits.
    reg [24:0] lookup_tags[0:3];
    reg [3:0] lookup_valid;
    wire signed [16:0] x0=$signed(in_x[23:8]),y0=$signed(in_y[23:8]);
    wire [3:0] decoded_bounds,line_hit;
    wire [31:0] decoded_number[0:3];
    wire [ADDRESS_BITS-1:0] pixel_address[0:3];
    wire all_hit=&line_hit;
    wire stage1_ready=!v1 || out_ready;
    wire stage0_ready=!v0 || stage1_ready;
    wire empty=!v0 && !v1;
    wire accept_query;
    assign frame_ready=state==IDLE && empty && !query_valid && !failed;
    assign in_ready=frame_loaded && !frame_valid && !failed && state==IDLE &&
        (!query_valid || accept_query);
    wire accept_frame=frame_valid && frame_ready;
    // A pending next-frame request blocks new input but never the registered
    // old-frame query. This is necessary for FIFO/query/result drain.
    wire accept_fast=query_valid && !failed && state==IDLE && all_hit && stage0_ready;
    wire accept_slow=query_valid && !failed && state==IDLE && !all_hit && empty;
    wire capture_slow_payload=query_valid && !failed && state==IDLE;
    assign accept_query=accept_fast || accept_slow;
    (* PAP_MAX_FANOUT = 32 *) wire decode_query=in_valid && in_ready;
    wire consume_fast=v1 && out_ready && !failed;
    wire consume_slow=state==RESULT && out_ready && !failed;
    // A slow miss may replace lines after the next head was decoded.
    // Refresh that HELD head on the existing RESULT->IDLE transition.
    wire lookup_refresh=consume_slow && query_valid;
    wire lookup_load=decode_query || lookup_refresh;
    assign out_valid=!failed && (v1 || state==RESULT);
    assign p00=v1 ? fast_pixel[0]:slow_pixel[0];
    assign p10=v1 ? fast_pixel[1]:slow_pixel[1];
    assign p01=v1 ? fast_pixel[2]:slow_pixel[2];
    assign p11=v1 ? fast_pixel[3]:slow_pixel[3];
    assign fx=v1 ? fx1:slow_fx;
    assign fy=v1 ? fy1:slow_fy;
    assign out_tag=v1 ? tag1:slow_tag;
    assign hits=hit_count;assign misses=miss_count;assign completed_queries=complete_count;
    assign araddr=base+({3'b0,selected_block}<<6);
    assign arlen=7;
    // Once asserted, ARVALID survives timeout/fault until its handshake. Reset
    // is the recovery boundary; an asserted DDR transaction is never withdrawn.
    assign arvalid=address_pending;
    wire accept_address=address_pending && arready;
    wire receiving=state==FILL || (state==AR && accept_address);
    wire progress=accept_address || (state==FILL && rvalid);
    wire signed [16:0] nx=slow_x+$signed({16'b0,neighbour[0]});
    wire signed [16:0] ny=slow_y+$signed({16'b0,neighbour[1]});
    wire neighbour_in_bounds=nx>=0 && nx<WIDTH && ny>=0 && ny<HEIGHT;
    wire [31:0] selected_number=ny*WIDTH+nx;
    function [23:0] expand565(input [15:0] p);
        expand565={p[15:11],p[15:13],p[10:5],p[10:9],p[4:0],p[4:2]};
    endfunction
    genvar n;
    generate for(n=0;n<4;n=n+1)begin: neighbour_input
        wire signed [16:0] ix=x0+(n%2),iy=y0+(n/2);
        assign decoded_bounds[n]=ix>=0 && ix<WIDTH && iy>=0 && iy<HEIGHT;
        assign decoded_number[n]=iy*WIDTH+ix;
        assign pixel_address[n]=pixel_number[n][2 +: ADDRESS_BITS];
        // Refresh selects the held head; otherwise address the incoming head.
        // Do not use decode_query as the address selector: its ready feedback
        // would put the old tag decision back into the new RAM-to-D path.
        wire [INDEX_BITS-1:0] lookup_line_index=lookup_refresh ?
            pixel_number[n][7 +: INDEX_BITS]:decoded_number[n][7 +: INDEX_BITS];
        always @(posedge clk)begin
            if(lookup_load)begin
                lookup_tags[n]<=tags[lookup_line_index];
                lookup_valid[n]<=valid_lines[lookup_line_index];
            end
        end
        assign line_hit[n]=!in_bounds[n] || (lookup_valid[n] &&
            lookup_tags[n]==pixel_number[n][31:7]);
    end endgenerate
    wire [ADDRESS_BITS-1:0] even_upper=pixel_number[0][0] ? pixel_address[1]:pixel_address[0];
    wire [ADDRESS_BITS-1:0] odd_upper=pixel_number[0][0] ? pixel_address[0]:pixel_address[1];
    wire [ADDRESS_BITS-1:0] even_lower=pixel_number[2][0] ? pixel_address[3]:pixel_address[2];
    wire [ADDRESS_BITS-1:0] odd_lower=pixel_number[2][0] ? pixel_address[2]:pixel_address[3];
    // Two mutually exclusive read/write ports per even/odd array. No RAM
    // or read-register reset; scatter uses both ports, normal reads use A/B.
    wire scatter_write=rst_n && state==SCATTER && !failed;
    wire read_enable=rst_n && !failed && (accept_fast || state==LOAD);
    wire read_lower=rst_n && accept_fast;
    wire [ADDRESS_BITS-1:0] write_address_a={selected_line,scatter_group,1'b0};
    wire [ADDRESS_BITS-1:0] write_address_b={selected_line,scatter_group,1'b1};
    wire [ADDRESS_BITS-1:0] even_a=scatter_write ? write_address_a:state==LOAD ? selected_pixel_address:even_upper;
    wire [ADDRESS_BITS-1:0] odd_a=scatter_write ? write_address_a:state==LOAD ? selected_pixel_address:odd_upper;
    wire [ADDRESS_BITS-1:0] even_b=scatter_write ? write_address_b:even_lower;
    wire [ADDRESS_BITS-1:0] odd_b=scatter_write ? write_address_b:odd_lower;
    wire [127:0] fill_octet=fill_buffer[scatter_group[3:1]][scatter_group[0]*128 +:128];
    (* ram_style="block" *) reg [31:0] even_pixels[0:LINES*32-1];
    (* ram_style="block" *) reg [31:0] odd_pixels[0:LINES*32-1];
    reg [31:0] even_q_upper,odd_q_upper,even_q_lower,odd_q_lower;
    always @(posedge clk)begin
        if(scatter_write)even_pixels[even_a]<={fill_octet[47:32],fill_octet[15:0]};
        else if(read_enable)even_q_upper<=even_pixels[even_a];
    end
    always @(posedge clk)begin
        if(scatter_write)even_pixels[even_b]<={fill_octet[111:96],fill_octet[79:64]};
        else if(read_lower)even_q_lower<=even_pixels[even_b];
    end
    always @(posedge clk)begin
        if(scatter_write)odd_pixels[odd_a]<={fill_octet[63:48],fill_octet[31:16]};
        else if(read_enable)odd_q_upper<=odd_pixels[odd_a];
    end
    always @(posedge clk)begin
        if(scatter_write)odd_pixels[odd_b]<={fill_octet[127:112],fill_octet[95:80]};
        else if(read_lower)odd_q_lower<=odd_pixels[odd_b];
    end
    wire [31:0] selected_pair=selected_parity ? odd_q_upper:even_q_upper;
    wire [15:0] selected_word=selected_lane ? selected_pair[31:16]:selected_pair[15:0];
    integer i;
    always @(posedge clk)begin
        if(!rst_n)begin
            state<=IDLE;frame_loaded<=0;address_pending<=0;base<=0;valid_lines<=0;
            slow_x<=0;slow_y<=0;neighbour<=0;slow_fx<=0;slow_fy<=0;slow_tag<=0;
            selected_block<=0;selected_line<=0;selected_pixel_address<=0;selected_parity<=0;selected_lane<=0;
            fill_beat<=0;scatter_group<=0;watchdog<=0;failed<=0;fault<=0;
            hit_count<=0;miss_count<=0;complete_count<=0;
            v0<=0;v1<=0;bounds0<=0;parity0<=0;lane0<=0;fx0<=0;fy0<=0;fx1<=0;fy1<=0;tag0<=0;tag1<=0;
            query_valid<=0;query_x<=0;query_y<=0;query_fx<=0;query_fy<=0;query_tag<=0;in_bounds<=0;
            for(i=0;i<4;i=i+1)begin slow_pixel[i]<=0;fast_pixel[i]<=0;pixel_number[i]<=0;end
        end else begin
            // Preload the CURRENT registered query only while slow storage is idle.
            // Never use incoming/decode_query data: miss consume/refill can overlap.
            if(capture_slow_payload)begin
                slow_x<=query_x;slow_y<=query_y;
                slow_fx<=query_fx;slow_fy<=query_fy;slow_tag<=query_tag;
            end
            // Same-cycle consume/refill sustains one decoded fast hit per clk.
            // If lookup or the DDR slow path stalls, the complete decoded head
            // remains unchanged even while the external FIFO receives input.
            if(decode_query)begin
                query_valid<=1;query_x<=x0;query_y<=y0;
                query_fx<=in_x[7:0];query_fy<=in_y[7:0];query_tag<=in_tag;in_bounds<=decoded_bounds;
                for(i=0;i<4;i=i+1)pixel_number[i]<=decoded_number[i];
            end else if(accept_query)query_valid<=0;
            if(address_pending && arready)address_pending<=0;
            if(progress || (state!=AR && state!=FILL))watchdog<=0;
            else watchdog<=watchdog+1'b1;
            if(stage1_ready)begin
                v1<=v0;fx1<=fx0;fy1<=fy0;tag1<=tag0;
                if(v0)begin
                    fast_pixel[0]<=bounds0[0] ? expand565(lane0[0] ? (parity0[0] ? odd_q_upper[31:16]:even_q_upper[31:16]):(parity0[0] ? odd_q_upper[15:0]:even_q_upper[15:0])):24'd0;
                    fast_pixel[1]<=bounds0[1] ? expand565(lane0[1] ? (parity0[1] ? odd_q_upper[31:16]:even_q_upper[31:16]):(parity0[1] ? odd_q_upper[15:0]:even_q_upper[15:0])):24'd0;
                    fast_pixel[2]<=bounds0[2] ? expand565(lane0[2] ? (parity0[2] ? odd_q_lower[31:16]:even_q_lower[31:16]):(parity0[2] ? odd_q_lower[15:0]:even_q_lower[15:0])):24'd0;
                    fast_pixel[3]<=bounds0[3] ? expand565(lane0[3] ? (parity0[3] ? odd_q_lower[31:16]:even_q_lower[31:16]):(parity0[3] ? odd_q_lower[15:0]:even_q_lower[15:0])):24'd0;
                end
            end
            if(stage0_ready)v0<=accept_fast;
            if(accept_fast)begin
                bounds0<=in_bounds;fx0<=query_fx;fy0<=query_fy;tag0<=query_tag;
                for(i=0;i<4;i=i+1)begin parity0[i]<=pixel_number[i][0];lane0[i]<=pixel_number[i][1];end
                hit_count<=hit_count+{31'd0,in_bounds[0]}+{31'd0,in_bounds[1]}+
                    {31'd0,in_bounds[2]}+{31'd0,in_bounds[3]};
            end
            if(consume_fast || consume_slow)complete_count<=complete_count+1'b1;
            case(state)
                IDLE:begin
                    if(accept_frame)begin base<=frame_base;valid_lines<=0;frame_loaded<=1;end
                    else if(accept_slow)begin
                        neighbour<=0;state<=SELECT;
                    end
                end
                SELECT:begin
                    if(!neighbour_in_bounds)begin
                        slow_pixel[neighbour]<=0;
                        if(neighbour==3)state<=RESULT;else neighbour<=neighbour+1'b1;
                    end else begin
                        selected_block<=selected_number[31:7];selected_line<=selected_number[7 +: INDEX_BITS];
                        selected_pixel_address<=selected_number[2 +: ADDRESS_BITS];selected_parity<=selected_number[0];selected_lane<=selected_number[1];
                        // Slow address arithmetic ends here. The next cycle
                        // reads/compares the current tag and invalidates only
                        // the registered line, never a combinational ny*WIDTH.
                        state<=CHECK;
                    end
                end
                CHECK:begin
                        if(valid_lines[selected_line] && tags[selected_line]==selected_block)begin
                            hit_count<=hit_count+1'b1;state<=LOAD;
                        end else begin
                            valid_lines[selected_line]<=0;
                            miss_count<=miss_count+1'b1;fill_beat<=0;address_pending<=1;state<=AR;
                        end
                end
                AR:if(accept_address)state<=FILL;
                FILL:begin end
                SCATTER:begin
                    if(scatter_group==15)begin
                        valid_lines[selected_line]<=1;tags[selected_line]<=selected_block;state<=LOAD;
                    end else scatter_group<=scatter_group+1'b1;
                end
                LOAD:state<=PICK;
                PICK:begin
                    slow_pixel[neighbour]<=expand565(selected_word);
                    if(neighbour==3)state<=RESULT;
                    else begin neighbour<=neighbour+1'b1;state<=SELECT;end
                end
                RESULT:if(out_ready)state<=IDLE;
                FAULT:state<=FAULT;
                default:begin failed<=1;fault<=8'hff;state<=FAULT;end
            endcase
            if(!failed && rvalid)begin
                if(!receiving)begin failed<=1;fault<=8'h04;state<=FAULT;valid_lines[selected_line]<=0;end
                else if(rid!=0 || rlast!=(fill_beat==7))begin failed<=1;fault<=8'h03;state<=FAULT;valid_lines[selected_line]<=0;end
                else begin
                    fill_buffer[fill_beat]<=rdata;
                    if(fill_beat==7)begin scatter_group<=0;state<=SCATTER;end
                    else fill_beat<=fill_beat+1'b1;
                end
            end
            if(!failed && &watchdog && !progress && (state==AR || state==FILL))begin
                failed<=1;fault<=8'h01;state<=FAULT;valid_lines[selected_line]<=0;
            end
        end
    end
endmodule
